package com.app.ecom_microservices.service;

import java.util.List;
import java.util.Optional;
import java.util.Map;
import com.app.ecom_microservices.model.Category;

public interface CategoryService {
    public Category createCategory(Category category);
    public List<Category> getAllCategories();
    public Category saveCategory(Category category);
    public Optional<Category> getCategoryById(Long id);
    public Category updateCategory(Long id, Category category);
    public void deleteCategory(Long id);
    public Category patchCategory(Long id, Map<String, Object> fields);
}
