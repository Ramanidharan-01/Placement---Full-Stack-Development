package com.example.JWT.DEMO.Controller;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.JWT.DEMO.Service.JWTService;
import com.example.JWT.DEMO.Service.UserService;
import com.example.JWT.DEMO.dto.AuthResponse;
import com.example.JWT.DEMO.dto.LoginRequest;
import com.example.JWT.DEMO.dto.RegisterRequest;
import com.example.JWT.DEMO.entity.User;
import com.example.JWT.DEMO.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {
    private final JWTService jwtService;
    private final UserService userService;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @PostMapping("/register")
    public String register(@RequestBody RegisterRequest request){
        userService.register(request);
        return "User Created";
    }

    @PostMapping("/login")
    public AuthResponse login(@RequestBody LoginRequest request){
    System.out.println("---- LOGIN ATTEMPT REACHED CONTROLLER ----");
    System.out.println("Trying to login with username: " + request.getUserName());
        User user = userRepository.findByUserName(request.getUserName())
            .orElseThrow(() -> new RuntimeException("User Not Found"));
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())){
            throw new RuntimeException("Invalid Credentials");
        }
        String token = jwtService.generateToken(user.getUserName());
        return new AuthResponse(token);
    }

    @GetMapping("/hello")
    public String hello(){
        return "JWT implemented";
    }
}

