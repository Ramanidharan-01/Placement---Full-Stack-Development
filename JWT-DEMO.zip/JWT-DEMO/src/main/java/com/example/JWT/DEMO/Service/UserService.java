package com.example.JWT.DEMO.Service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.JWT.DEMO.dto.RegisterRequest;
import com.example.JWT.DEMO.entity.User;
import com.example.JWT.DEMO.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

public void register(RegisterRequest request){
        User user = User.builder()
            .userName(request.getUserName())
            .password(passwordEncoder.encode(request.getPassword()))
            .role("USER")
            .build();
        userRepository.save(user);
    }
}

