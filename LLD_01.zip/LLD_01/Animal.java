public class Animal implements Eatable, Sleepable, Talkable, Workable {
    @Override
    public void eat() {
        System.out.println("Animal is eating");
    }

    @Override
    public void sleep() {
        System.out.println("Animal is sleeping");
    }

    @Override
    public void talk() {
        throw new UnsupportedOperationException("Animal cannot talk");
    }

    @Override
    public void work() {
        throw new UnsupportedOperationException("Animal cannot work");
    }
}
