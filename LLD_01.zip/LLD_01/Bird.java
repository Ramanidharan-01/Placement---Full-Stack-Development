interface Bird {
    void move();
    void eat();
}