public class CurrentAccount implements AccountType {
    
    @Override
    public double calculateInterest(double balance) {
        return balance * 0.03;
    }
    
}