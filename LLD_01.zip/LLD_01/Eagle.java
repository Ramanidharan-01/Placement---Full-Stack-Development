public class Eagle extends FlyingBird {
    @Override
    public void eat() {
        System.out.println("Eagle is eating");
    }
    @Override
    public void move() {
        System.out.println("Eagle moves by flying");
    }
}
