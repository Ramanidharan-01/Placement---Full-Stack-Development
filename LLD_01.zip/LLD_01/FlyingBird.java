public class FlyingBird implements Bird {
    @Override
    public void move() {
        System.out.println("Flying bird moves by Flying");
    }
    @Override
    public void eat() {
        System.out.println("Flying bird is eating");
    }
}
