public class InterestCalculator {
    public double calculateInterest(double balance, AccountType accountType){
        return accountType.calculateInterest(balance);
    }
}