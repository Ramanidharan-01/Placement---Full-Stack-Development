public class Main {
    public static void main(String[] args) {
        PaymentService paymentService = new PaymentService();
        paymentService.processpayment(new CreditCard());
        paymentService.processpayment(new DebitCard());
        paymentService.processpayment(new PayPal());
        
        InterestCalculator ic = new InterestCalculator();
        System.out.println("Interest for saving account:" + ic.calculateInterest(100000, new SavingAccount()));
        System.out.println("Interest for current account:" + ic.calculateInterest(100000, new CurrentAccount()));
        
        Bird b1 = new Eagle();
        b1.move();
        b1.eat();
        Bird b2 = new Penguin();
        b2.move();
        b2.eat();
        Bird b3 = new Ostrich();
        b3.move();
        b3.eat();
        
        Person p = new Person();
        p.eat();
        p.sleep();
        p.work();

        Animal animal = new Animal();
        animal.eat();
        animal.sleep();
        animal.talk();
        animal.work();

        Robot r = new Robot();
        r.eat();
        r.sleep();
        r.talk();
        r.work();
    }
}