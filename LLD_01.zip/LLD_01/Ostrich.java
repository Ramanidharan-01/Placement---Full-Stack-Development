public class Ostrich extends WalkingBird {
    @Override
    public void eat() {
        System.out.println("Ostrich is eating");
    }
    @Override
    public void move() {
        System.out.println("Ostrich moves by walking");
    }
}
