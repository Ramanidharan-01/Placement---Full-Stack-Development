
public class PaymentService {

    public PaymentService() {
    }
    public void processpayment(PaymentMethod paymentMethod){
        paymentMethod.pay();
    }
}
