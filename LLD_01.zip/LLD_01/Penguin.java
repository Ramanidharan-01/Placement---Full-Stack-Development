public class Penguin extends SwimmingBird {
    @Override
    public void eat() {
        System.out.println("Penguin is eating");
    }
    @Override
    public void move() {
        System.out.println("Penguin moves by swimming");
    }
}
