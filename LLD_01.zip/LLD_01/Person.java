public class Person implements Eatable, Sleepable, Workable, Talkable {
    @Override
    public void eat() {
        System.out.println("Person is eating");
    }

    @Override
    public void sleep() {
        System.out.println("Person is sleeping");
    }

    @Override
    public void work() {
        System.out.println("Person is working");
    }

    @Override
    public void talk(){
        System.out.println("Person is talking");
    }
}
