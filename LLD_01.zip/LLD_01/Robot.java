public class Robot implements Workable,Eatable,Sleepable,Talkable {
    @Override
    public void work() {
        System.out.println("Robot is working");
    }
    @Override
    public void talk() {
        System.out.println("Robot is talking");
    }
    @Override
    public void eat() {
        throw new UnsupportedOperationException("Robot cannot eat");
    }
    @Override
    public void sleep() {
        throw new UnsupportedOperationException("Robot cannot sleep");
    }
}
