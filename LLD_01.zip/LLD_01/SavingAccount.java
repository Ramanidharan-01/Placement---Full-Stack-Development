public class SavingAccount implements AccountType {

    @Override
    public double calculateInterest(double balance) {
        return balance * 0.05;
    }
    
}
