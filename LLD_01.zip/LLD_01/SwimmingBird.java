public class SwimmingBird implements Bird {
    @Override
    public void move() {
        System.out.println("Swimming bird moves by Swimming");
    }

    @Override
    public void eat() {
        System.out.println("Swimming bird is eating");
    }
}
