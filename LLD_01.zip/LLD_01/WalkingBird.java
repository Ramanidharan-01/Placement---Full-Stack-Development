public class WalkingBird implements Bird {
    @Override
    public void move() {
        System.out.println("Walking bird moves by Walking");
    }

    @Override
    public void eat() {
        System.out.println("Walking bird is eating");
    }
}
