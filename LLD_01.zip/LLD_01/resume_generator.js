const {
  Document, Packer, Paragraph, TextRun, ExternalHyperlink, AlignmentType,
  LevelFormat, BorderStyle, TabStopType, TabStopPosition, convertInchesToTwip
} = require('docx');
const fs = require('fs');

// ---------- THEME ----------
const NAVY = "1F3864";
const NAVY_LINE = "2E5395";
const GRAY = "595959";
const LINKBLUE = "1155CC";
const BLACK = "1A1A1A";
const FONT = "Kalinga"; // Updated to Kalinga

const BODY_SZ = 21;      // 10.5pt
const SMALL_SZ = 19;     // 9.5pt
const NAME_SZ = 46;      // 23pt
const TITLE_SZ = 22;     // 11pt
const SECTION_SZ = 24;   // 12pt

// page geometry
const MARGIN_TOP = 612;     // 0.425"
const MARGIN_BOTTOM = 612;  // 0.425"
const MARGIN_SIDE = 792;    // 0.55"
const PAGE_W = 12240, PAGE_H = 15840;
const CONTENT_W = PAGE_W - 2 * MARGIN_SIDE; // 10656

// ---------- HELPERS ----------
function sectionHeader(text) {
  return new Paragraph({
    spacing: { before: 170, after: 70, line: 240, lineRule: "auto" },
    border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: NAVY_LINE, space: 2 } },
    children: [new TextRun({ text, bold: true, color: NAVY, size: SECTION_SZ, font: FONT })],
  });
}

function labelLine(label, rest, opts = {}) {
  return new Paragraph({
    spacing: { before: 0, after: opts.after ?? 30, line: 235, lineRule: "auto" },
    children: [
      new TextRun({ text: label + " ", bold: true, color: BLACK, size: BODY_SZ, font: FONT }),
      new TextRun({ text: rest, color: BLACK, size: BODY_SZ, font: FONT }),
    ],
  });
}

function entryHeader(title, dateLoc, opts = {}) {
  return new Paragraph({
    tabStops: [{ type: TabStopType.RIGHT, position: CONTENT_W }],
    spacing: { before: opts.before ?? 130, after: 0, line: 235, lineRule: "auto" },
    children: [
      new TextRun({ text: title, bold: true, color: BLACK, size: BODY_SZ, font: FONT }),
      new TextRun({ text: "\t" + dateLoc, color: GRAY, size: SMALL_SZ, font: FONT }),
    ],
  });
}

function subLine(text, opts = {}) {
  return new Paragraph({
    spacing: { before: 10, after: opts.after ?? 35, line: 230, lineRule: "auto" },
    children: [new TextRun({ text, italics: true, color: GRAY, size: SMALL_SZ, font: FONT })],
  });
}

function subLineWithLink(prefix, url, rest, opts = {}) {
  return new Paragraph({
    spacing: { before: 10, after: opts.after ?? 35, line: 230, lineRule: "auto" },
    children: [
      new ExternalHyperlink({
        link: url,
        children: [new TextRun({ text: prefix, color: LINKBLUE, underline: {}, size: SMALL_SZ, font: FONT })],
      }),
      new TextRun({ text: "   |   " + rest, italics: true, color: GRAY, size: SMALL_SZ, font: FONT }),
    ],
  });
}

function bullet(text, opts = {}) {
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    spacing: { before: 0, after: opts.after ?? 28, line: 232, lineRule: "auto" },
    children: [new TextRun({ text, color: BLACK, size: BODY_SZ, font: FONT })],
  });
}

// ---------- HEADER BLOCK ----------
const headerBlock = [
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 30, line: 240, lineRule: "auto" },
    children: [new TextRun({ text: "RAMANIDHARAN D", bold: true, color: NAVY, size: NAME_SZ, font: FONT })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 0, after: 50, line: 240, lineRule: "auto" },
    children: [new TextRun({ text: "AI / ML / DL Engineer  |  Software Developer", color: GRAY, size: TITLE_SZ, font: FONT })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: NAVY_LINE, space: 6 } },
    spacing: { before: 0, after: 140, line: 235, lineRule: "auto" },
    children: [
      new TextRun({ text: "+91 95665 26086  |  ", color: GRAY, size: SMALL_SZ, font: FONT }),
      new ExternalHyperlink({
        link: "mailto:ramanidharan333@gmail.com",
        children: [new TextRun({ text: "ramanidharan333@gmail.com", color: LINKBLUE, underline: {}, size: SMALL_SZ, font: FONT })],
      }),
      new TextRun({ text: "  |  ", color: GRAY, size: SMALL_SZ, font: FONT }),
      new ExternalHyperlink({
        link: "https://www.linkedin.com/in/ramanidharan-d-313277325",
        children: [new TextRun({ text: "LinkedIn", color: LINKBLUE, underline: {}, size: SMALL_SZ, font: FONT })],
      }),
      new TextRun({ text: "  |  ", color: GRAY, size: SMALL_SZ, font: FONT }),
      new ExternalHyperlink({
        link: "https://github.com/Ramanidharan-01",
        children: [new TextRun({ text: "GitHub", color: LINKBLUE, underline: {}, size: SMALL_SZ, font: FONT })],
      }),
      new TextRun({ text: "  |  ", color: GRAY, size: SMALL_SZ, font: FONT }),
      new ExternalHyperlink({
        link: "https://www.geeksforgeeks.org/profile/user_3krcft9tf3h",
        children: [new TextRun({ text: "GFG", color: LINKBLUE, underline: {}, size: SMALL_SZ, font: FONT })],
      }),
      new TextRun({ text: "  |  ", color: GRAY, size: SMALL_SZ, font: FONT }),
      new ExternalHyperlink({
        link: "https://leetcode.com/u/Ramanidharan/",
        children: [new TextRun({ text: "LeetCode", color: LINKBLUE, underline: {}, size: SMALL_SZ, font: FONT })],
      }),
      new TextRun({ text: "  |  Coimbatore, Tamil Nadu", color: GRAY, size: SMALL_SZ, font: FONT }),
    ],
  }),
];

// ---------- CAREER SUMMARY ----------
const summaryBlock = [
  sectionHeader("CAREER SUMMARY"),
  new Paragraph({
    spacing: { before: 0, after: 120, line: 240, lineRule: "auto" },
    children: [new TextRun({
      text: "Innovative AI/ML/DL Engineer and Software Developer specializing in high-performance Machine Learning, scalable System Design, and Data Science. Proven expertise in architecting hybrid Deep Learning pipelines and JAX-accelerated Reinforcement Learning environments for real-time anomaly detection and predictive analytics. Adept at bridging complex Data Structures with robust full-stack development, leveraging Spring Boot, DBMS architectures, and modern frontend technologies. Combines rigorous algorithmic efficiency with Data Analytics and Digital Marketing insights to engineer highly optimized, edge-deployable, and user-centric solutions.",
      color: BLACK, size: BODY_SZ, font: FONT,
    })],
  }),
];

// ---------- TECHNICAL SKILLS ----------
const skillsBlock = [
  sectionHeader("TECHNICAL SKILLS"),
  labelLine("Languages:", "Python, Java, C, R, JavaScript, TypeScript, HTML5, CSS3"),
  labelLine("AI / ML / DL:", "Reinforcement Learning, Deep Learning, NLP, RAG, AI Agents, XGBoost, Autoencoders, PPO, Transformers, JAX, Flax"),
  labelLine("Frameworks & Tools:", "React, Node.js, FastAPI, Spring Boot, Docker, Redis, Supabase, PostgreSQL, SQL, Ollama, Hugging Face, Google Colab"),
  labelLine("Developer Tools:", "VS Code, GitHub, Vercel, Netlify"),
  labelLine("Competitive Programming:", "200+ problems on GeeksforGeeks, 70+ on LeetCode (DSA — Arrays, Graphs, DP, Trees)"),
  labelLine("Soft Skills:", "Leadership, Communication, Problem Solving, Adaptability, SEO Optimization", { after: 120 }),
];

// ---------- EXPERIENCE ----------
const experienceBlock = [
  sectionHeader("EXPERIENCE"),
  entryHeader("AI Intern — Appin Technologies", "May 2026  |  Coimbatore, Tamil Nadu", { before: 0 }),
  bullet("Gained hands-on exposure to Large Language Models (LLMs), prompt engineering, and AI-powered workflow tools across enterprise-focused use cases."),
  bullet("Worked with generative AI APIs and toolkits to evaluate model capabilities for automation and productivity enhancement; explored responsible AI deployment patterns."),
  bullet("Investigated model deployment trade-offs including latency optimization, inference scaling, and integration with existing enterprise software systems.", { after: 120 }),
];

// ---------- PROJECTS ----------
const projectsBlock = [
  sectionHeader("PROJECTS"),

  entryHeader("UNO Player — Reinforcement Learning Agent", "Apr 2026 – Jun 2026", { before: 0 }),
  subLine("JAX  ·  Flax  ·  PPO  ·  Gated Transformer-XL  ·  FastAPI  ·  Redis  ·  Docker"),
  bullet("Architected and trained a scalable RL agent for UNO using JAX and Flax, achieving training throughputs of millions of steps/second via a fully vectorized environment."),
  bullet("Designed an advanced PPO pipeline with a GTrXL memory core, Token Self-Attention for dynamic card-hand representation, and auxiliary belief-state loss to predict hidden opponent cards under partial observability."),
  bullet("Engineered a multi-agent League Training framework with historical self-play, Elo rating tracking, and annealed reward shaping to maximize convergence and exploitability resistance."),
  bullet("Productized via a stateless, low-latency async inference API using FastAPI, Redis, and Docker for robust concurrent web-client execution.", { after: 120 }),

  entryHeader("FinSentinel AI — Real-Time Fraud Detection Platform", "Jun 2025 – Mar 2026"),
  subLine("Autoencoders  ·  XGBoost  ·  PCA  ·  React  ·  Node.js  ·  Supabase"),
  bullet("Architected a hybrid ML/DL pipeline integrating Autoencoders for latent behavioral mapping with a supervised XGBoost meta-classifier to detect zero-day financial fraud in real time."),
  bullet("Engineered a high-throughput PCA pipeline compressing high-dimensional transactional data into 28 principal components; achieved ROC-AUC 0.9883, 97% Precision, F1-Score 95.5%."),
  bullet("Built a full-stack threat intelligence dashboard (React, Node.js, Supabase) with live transaction monitoring, dynamic anomaly scoring visualizers, and interactive model transparency tools.", { after: 120 }),

  entryHeader("Sustatio — IoT-Driven Circular Economy Platform (SIH'25)", "Aug 2025 – Sep 2025"),
  subLine("React  ·  TypeScript  ·  Node.js  ·  IoT Edge Computing  ·  RBAC  ·  AI Decision Support"),
  bullet("Architected an end-to-end IoT ecosystem bridging edge-computing smart dustbins with cloud infrastructure, enabling automated waste classification and circular economy routing."),
  bullet("Implemented AI-driven decision support, predictive civic intelligence tracking, and strict RBAC across a distributed sensor-to-cloud network; presented at Smart India Hackathon 2025.", { after: 120 }),

  entryHeader("Suzume — Cinematic Immersive Web Experience", "May 2026"),
  subLineWithLink("Live Demo: suzume-zeta.vercel.app", "https://suzume-zeta.vercel.app/", "Vanilla JS  ·  HTML5 Canvas  ·  CSS3  ·  Vercel"),
  bullet("Engineered a heavily UI-driven cinematic storytelling experience using pure HTML5, CSS3, and Vanilla JS — no frameworks — demonstrating mastery of native browser APIs at production scale."),
  bullet("Built a custom Canvas Animation Engine for real-time generative particle systems (petals, star fields, glowing objects) at 60 fps; implemented a custom cursor subsystem with smooth interpolation and hover-state expansion."),
  bullet("Architected 7 interactive story sections with glassmorphism UI, section-based scroll animation, ambient music toggle, and modal overlay system; deployed to Vercel as a zero-build static site.", { after: 120 }),
];

// ---------- OPEN SOURCE ----------
const openSourceBlock = [
  sectionHeader("OPEN SOURCE CONTRIBUTIONS"),

  entryHeader("hitl-flow-kit — Human-in-the-Loop AI Workflow Framework", "2026", { before: 0 }),
  subLineWithLink("github.com/premier-svg/hitl-flow-kit", "https://github.com/premier-svg/hitl-flow-kit", "Workflow Orchestration  ·  Human-in-the-Loop AI", { after: 25 }),
  bullet("Contributed to an open-source HITL flow orchestration toolkit, improving AI decision pipeline transparency and human intervention control mechanisms.", { after: 100 }),

  entryHeader("ORG2 — yorgai Organization AI Framework", "2026"),
  subLineWithLink("github.com/yorgai/ORG2", "https://github.com/yorgai/ORG2", "Multi-Agent Systems  ·  Workflow Automation", { after: 25 }),
  bullet("Contributed to ORG2, an AI-driven organizational intelligence framework, enhancing multi-agent coordination and workflow automation capabilities.", { after: 120 }),
];

// ---------- HACKATHONS ----------
const hackathonsBlock = [
  sectionHeader("HACKATHONS & COMPETITIONS"),
  bullet("Won 1st Place — NGP ITech Project Expo 2026 (Sustatio, Circular Economy IoT Platform)."),
  bullet("Top 5 — Smart India Hackathon 2025 (SIH'25), College Level."),
  bullet("Participated — Madras IT  ·  Coimbatore IT  ·  PSG College of Technology  ·  KIT  ·  Deep Tech Innovation Challenge.", { after: 120 }),
];

// ---------- CERTIFICATIONS ----------
const certsBlock = [
  sectionHeader("CERTIFICATIONS & TRAINING"),
  bullet("Attended — NIT Trichy Summer Internship Program 2025 (AI/ML Track)."),
  bullet("NPTEL — Human Computer Interaction (HCI), Indian Institute of Technology."),
  bullet("NPTEL — Cloud Computing (CC), Indian Institute of Technology."),
  bullet("Building with AI — Saylor's Academy.", { after: 120 }),
];

// ---------- EDUCATION ----------
const educationBlock = [
  sectionHeader("EDUCATION"),
  entryHeader("B.Tech — Artificial Intelligence & Data Science", "2024 – 2028 (Expected)", { before: 0 }),
  subLine("Dr. N.G.P. Institute of Technology, Coimbatore, Tamil Nadu   |   CGPA: 8.91 / 10.0", { after: 80 }),
  entryHeader("Higher Secondary Certificate (HSC)", "2024", { before: 40 }),
  subLine("KMHSS   |   Aggregate: 97%   |   Cut-off: 194.5 / 200", { after: 0 }),
];

// ---------- DOCUMENT ----------
const doc = new Document({
  styles: {
    default: { document: { run: { font: FONT, size: BODY_SZ } } },
  },
  numbering: {
    config: [
      {
        reference: "bullets",
        levels: [{
          level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 300, hanging: 230 } } },
        }],
      },
    ],
  },
  sections: [{
    properties: {
      page: {
        size: { width: PAGE_W, height: PAGE_H },
        margin: { top: MARGIN_TOP, bottom: MARGIN_BOTTOM, left: MARGIN_SIDE, right: MARGIN_SIDE },
      },
    },
    children: [
      ...headerBlock,
      ...summaryBlock,
      ...skillsBlock,
      ...experienceBlock,
      ...projectsBlock,
      ...openSourceBlock,
      ...hackathonsBlock,
      ...certsBlock,
      ...educationBlock,
    ],
  }],
});

Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync("Ramanidharan_D_Resume_ATS.docx", buffer);
  console.log("Success! Ramanidharan_D_Resume_ATS.docx generated.");
});
