package ADP;

public class Main {
    public static void main(String[] args) {
        PaymentProcessor stripePayment = new StripeAdapter("4111-1111-1111-1111");
        stripePayment.pay(8500);

        System.out.println("---");

        PaymentProcessor razorPayPayment = new RazorPayAdapter("9876543210");
        razorPayPayment.pay(500);
    }
}
