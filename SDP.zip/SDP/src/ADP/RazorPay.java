package ADP;

public class RazorPay {

    public void createPayment(String mobileNo, double amountInINR) {
        System.out.println("Rs." + amountInINR + " payment created on RazorPay using MobileNo: " + mobileNo);
    }
}
