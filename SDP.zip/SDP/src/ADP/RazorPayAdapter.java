package ADP;

public class RazorPayAdapter implements PaymentProcessor {
    private RazorPay razorPay;
    private String mobileNo;

    public RazorPayAdapter(String mobileNo) {
        this.razorPay = new RazorPay();
        this.mobileNo = mobileNo;
    }

    @Override
    public void pay(double amount) {
        razorPay.createPayment(mobileNo, amount);
    }
}
