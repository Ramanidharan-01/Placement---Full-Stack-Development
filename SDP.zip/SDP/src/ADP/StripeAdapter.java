package ADP;

public class StripeAdapter implements PaymentProcessor {
    private StripeProcessor stripeProcessor;
    private String cardNo;

    public StripeAdapter(String cardNo) {
        this.stripeProcessor = new StripeProcessor();
        this.cardNo = cardNo;
    }

    @Override
    public void pay(double amount) {
        double amountInUSD = amount / 100.0;
        stripeProcessor.makePayment(cardNo, amountInUSD);
    }
}
