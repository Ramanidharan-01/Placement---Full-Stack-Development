package ADP;

public class StripeProcessor {

    public void makePayment(String cardNo, double amountInUSD) {
        System.out.println("USD " + amountInUSD + " payment done via Stripe using Card: " + cardNo);
    }
}
