package BDP;

import java.util.ArrayList;

public class Email {
    private String receiver;
    private String cc;
    private String bcc;
    private String subject;
    private ArrayList<String> attachments;

    public Email(EmailBuilder builder) {
        this.receiver = builder.getReceiver();
        this.cc = builder.getCc();
        this.bcc = builder.getBcc();
        this.subject = builder.getSubject();
        builder.getBody();
        this.attachments = builder.getAttachments();
    }
}
