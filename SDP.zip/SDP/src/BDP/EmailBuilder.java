package BDP;
import java.util.ArrayList;

public class EmailBuilder {
    private String receiver;
    private String cc;
    private String bcc;
    private String subject;
    private String body;
    private ArrayList<String> attachments;
    
    public EmailBuilder setReceiver(String receiver){
        this.receiver = receiver;
        return this;
    }

    public EmailBuilder setCC(String cc){
        this.cc = cc;
        return this;
    }

    public EmailBuilder setBCC(String bcc){
        this.bcc = bcc;
        return this;
    }

    public EmailBuilder setSubject(String subject){
        this.subject = subject;
        return this;
    }

    public EmailBuilder setBody(String body){
        this.body = body;
        return this;
    }

    public EmailBuilder setAttachments(ArrayList<String> attachments){
        this.attachments = attachments;
        return this;
    }

    public String getReceiver() { return receiver; }
    public String getCc() { return cc; }
    public String getBcc() { return bcc; }
    public String getSubject() { return subject; }
    public String getBody() { return body; }
    public ArrayList<String> getAttachments() { return attachments; }

    public Email build() {
        return new Email(this);
    }
}
