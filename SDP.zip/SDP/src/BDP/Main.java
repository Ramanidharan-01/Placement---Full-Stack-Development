package BDP;

import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        EmailBuilder builder = new  EmailBuilder();
        builder.setReceiver("[EMAIL_ADDRESS]").setCC("[EMAIL_ADDRESS]").setBCC("[EMAIL_ADDRESS]").setSubject("Hey").setBody("Hello").setAttachments(new ArrayList<>(Arrays.asList("Hello.pdf","abc.doc")));
        System.out.println("Receiver: " + builder.getReceiver());
        System.out.println("Subject: " + builder.getSubject());
        System.out.println("Body: " + builder.getBody());
        System.out.println("CC: " + builder.getCc());
        System.out.println("BCC: " + builder.getBcc());
        System.out.println("Attachments: " + builder.getAttachments());
        Email email = builder.build();
        System.out.println("Email: " + email);
    }
}
