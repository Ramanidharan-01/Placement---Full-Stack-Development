package ChainOfResponsibilityDP;

public enum IssueType {
    BASIC,
    INTERMEDIATE,
    CRITICAL
}