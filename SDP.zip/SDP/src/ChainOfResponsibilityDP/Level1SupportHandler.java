package ChainOfResponsibilityDP;

public class Level1SupportHandler extends SupportHandler {

    @Override
    protected boolean canHandle(Ticket ticket) {
        return ticket.getIssueType() == IssueType.BASIC;
    }

    @Override
    protected void process(Ticket ticket) {
        System.out.println("Level 1 Support handled Ticket #" + ticket.getTicketId()
                + ": " + ticket.getDescription());
    }

    @Override
    protected String getHandlerName() {
        return "Level 1 Support";
    }
}
