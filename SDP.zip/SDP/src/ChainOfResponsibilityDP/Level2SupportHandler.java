package ChainOfResponsibilityDP;

public class Level2SupportHandler extends SupportHandler {

    @Override
    protected boolean canHandle(Ticket ticket) {
        return ticket.getIssueType() == IssueType.INTERMEDIATE;
    }

    @Override
    protected void process(Ticket ticket) {
        System.out.println("Level 2 Support handled Ticket #" + ticket.getTicketId()
                + ": " + ticket.getDescription());
    }

    @Override
    protected String getHandlerName() {
        return "Level 2 Support";
    }
}
