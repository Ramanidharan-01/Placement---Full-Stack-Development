package ChainOfResponsibilityDP;

public class Level3SupportHandler extends SupportHandler {

    @Override
    protected boolean canHandle(Ticket ticket) {
        return ticket.getIssueType() == IssueType.CRITICAL;
    }

    @Override
    protected void process(Ticket ticket) {
        System.out.println("Level 3 Support handled Ticket #" + ticket.getTicketId()
                + ": " + ticket.getDescription());
    }

    @Override
    protected String getHandlerName() {
        return "Level 3 Support";
    }
}
