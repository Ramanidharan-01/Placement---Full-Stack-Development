package ChainOfResponsibilityDP;

public class Main {
    public static void main(String[] args) {
        // Create handlers
        SupportHandler level1 = new Level1SupportHandler();
        SupportHandler level2 = new Level2SupportHandler();
        SupportHandler level3 = new Level3SupportHandler();

        // Build the chain: Level 1 -> Level 2 -> Level 3
        level1.setNextHandler(level2);
        level2.setNextHandler(level3);

        // Create tickets of varying severity
        Ticket t1 = new Ticket(101, IssueType.BASIC, "Password reset request");
        Ticket t2 = new Ticket(102, IssueType.INTERMEDIATE, "Software installation issue");
        Ticket t3 = new Ticket(103, IssueType.CRITICAL, "Server outage in production");

        // Send all tickets to the start of the chain
        System.out.println("=== Chain of Responsibility Demo ===\n");

        level1.handle(t1);
        System.out.println();

        level1.handle(t2);
        System.out.println();

        level1.handle(t3);
    }
}
