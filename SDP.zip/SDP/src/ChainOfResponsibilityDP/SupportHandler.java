package ChainOfResponsibilityDP;

public abstract class SupportHandler {
    protected SupportHandler nextHandler;

    public void setNextHandler(SupportHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public void handle(Ticket ticket) {
        if (canHandle(ticket)) {
            process(ticket);
        } else if (nextHandler != null) {
            System.out.println(getHandlerName() + " cannot handle Ticket #" + ticket.getTicketId()
                    + " (" + ticket.getIssueType() + "). Escalating...");
            nextHandler.handle(ticket);
        } else {
            System.out.println("No handler available for Ticket #" + ticket.getTicketId()
                    + ". Issue remains unresolved.");
        }
    }

    protected abstract boolean canHandle(Ticket ticket);

    protected abstract void process(Ticket ticket);

    protected abstract String getHandlerName();
}
