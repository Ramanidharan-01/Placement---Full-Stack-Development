package ChainOfResponsibilityDP;

public class Ticket {
    private int ticketId;
    private IssueType issueType;
    private String description;

    public Ticket(int ticketId, IssueType issueType, String description) {
        this.ticketId = ticketId;
        this.issueType = issueType;
        this.description = description;
    }

    public int getTicketId() {
        return ticketId;
    }

    public IssueType getIssueType() {
        return issueType;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return "Ticket [ticketId=" + ticketId + ", issueType=" + issueType + ", description=" + description + "]";
    }
}
