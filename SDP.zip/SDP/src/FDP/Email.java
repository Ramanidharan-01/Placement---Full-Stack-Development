package FDP;

public class Email implements Notification {
    @Override
    public void sendMessage(String message) {
        System.out.println("Sending Email: " + message);
    }
}
