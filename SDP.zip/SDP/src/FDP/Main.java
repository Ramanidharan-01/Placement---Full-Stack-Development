package FDP;

public class Main {
    public static void main(String[] args) {
        Notification smsNotification = NotificationFactory.createNotification("SMS");
        smsNotification.sendMessage("Hello via SMS!");

        Notification emailNotification = NotificationFactory.createNotification("Email");
        emailNotification.sendMessage("Hello via Email!");

        Notification whatsappNotification = NotificationFactory.createNotification("WhatsApp");
        whatsappNotification.sendMessage("Hello via WhatsApp!");
    }

}
