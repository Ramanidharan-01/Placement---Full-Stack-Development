package FDP;

public interface Notification {
    public void sendMessage(String message);
}
