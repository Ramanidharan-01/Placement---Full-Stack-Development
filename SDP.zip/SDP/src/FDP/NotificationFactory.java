package FDP;

public class NotificationFactory {
    public static Notification createNotification(String type) {
        if (type == null) {
            throw new IllegalArgumentException("Notification type cannot be null");
        }
        return switch (type.toUpperCase()) {
            case "SMS" -> new SMS();
            case "EMAIL" -> new Email();
            case "WHATSAPP" -> new Whatsapp();
            default -> throw new IllegalArgumentException("Unknown notification type: " + type);
        };
    }
}
