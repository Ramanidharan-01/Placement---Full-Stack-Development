package FDP;

public class Whatsapp implements Notification {
    @Override
    public void sendMessage(String message) {
        System.out.println("Sending WhatsApp: " + message);
    }
}
