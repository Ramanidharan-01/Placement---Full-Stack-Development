package FacadeDP;

public class Account {
    public boolean verifyAccount(String accountId){
        System.out.println("Account Verified");
        return true;
    }
}
