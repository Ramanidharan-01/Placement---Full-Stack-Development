package FacadeDP;

public class Funds {
    public boolean hasSufficientFunds(double amount){
        System.out.println("Sufficient Funds available");
        return true;
    }

    public void debitFunds(double amount){
        System.out.println("Debiting Funds: " + amount);
    }

    public void creditFunds(double amount){
        System.out.println("Crediting Funds: " + amount);
    }
}
