package FacadeDP;

public class Main {
    public static void main(String[] args) {
    Account account = new Account();
    Funds funds = new Funds();
    Notification notification = new Notification();

    System.out.println("Starting withdrawal process");
    if (account.verifyAccount("ABCD1234")){
        if (funds.hasSufficientFunds(1000)){
            funds.debitFunds(1000);
            notification.sendNotification("Withdrawal Successful");
        } else {
            notification.sendNotification("Withdrawal Failed: Insufficient Funds");
        }
    } else {
        notification.sendNotification("Withdrawal Failed: Invalid Account");
    }
    }
}