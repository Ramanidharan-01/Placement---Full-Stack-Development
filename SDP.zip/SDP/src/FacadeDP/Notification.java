package FacadeDP;

public class Notification {
    public void sendNotification(String message){
        System.out.println("Notification sent: " + message);
    }
}
