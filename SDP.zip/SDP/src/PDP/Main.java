package PDP;

public class Main {
    public static void main(String[] args) {
        UserService service = new ProxyUserService(new UserServiceImp());

        User admin = new User("Admin", Role.ADMIN);
        User normalUser = new User("User", Role.NORMAL);
        User anotherUser = new User("Target", Role.NORMAL);

        service.getUser(normalUser, anotherUser);
        service.getUser(admin, normalUser);

        System.out.println();

        service.deleteUser(admin, normalUser);

        service.deleteUser(normalUser, normalUser);

        service.deleteUser(normalUser, anotherUser);
    }
}
