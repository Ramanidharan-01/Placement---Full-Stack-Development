package PDP;

public class ProxyUserService implements UserService {
    private final UserService realService;

    public ProxyUserService(UserService realService) {
        this.realService = realService;
    }

    @Override
    public void getUser(User caller, User target) {
        realService.getUser(caller, target);
    }

    @Override
    public void deleteUser(User caller, User target) {
        if (caller.getRole() == Role.ADMIN || caller.getName().equals(target.getName())) {
            realService.deleteUser(caller, target);
        } else {
            System.out.println("Access denied: " + caller.getName() + " cannot delete " + target.getName());
        }
    }
}
