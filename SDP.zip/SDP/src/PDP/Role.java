package PDP;

public enum Role {
    ADMIN,
    NORMAL
}
