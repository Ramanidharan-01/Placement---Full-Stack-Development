package PDP;

public class UserServiceImp implements UserService {

    @Override
    public void getUser(User caller, User target) {
        System.out.println(caller.getName() + " viewed profile of: " + target.getName());
    }

    @Override
    public void deleteUser(User caller, User target) {
        System.out.println(caller.getName() + " deleted user: " + target.getName());
    }

}
