package SDP;
public class DBConnection {
    static private DBConnection connection;
    public DBConnection(String name) {
        System.out.println("Connected with :"+name);
    }

    static synchronized DBConnection getConnection(String name) {
        if(connection == null){
            connection = new DBConnection(name);
        }
        return connection;
    }
}
