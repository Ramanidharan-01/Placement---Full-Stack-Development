package SDP;
public class Main {
    public static void main(String[] args) {
        Thread t1 = new Thread(() -> DBConnection.getConnection("Connection 1"));
        Thread t2 = new Thread(() -> DBConnection.getConnection("Connection 2"));
        Thread t3 = new Thread(() -> DBConnection.getConnection("Connection 3"));
        t1.start();
        t2.start();
        t3.start();
    }
}
