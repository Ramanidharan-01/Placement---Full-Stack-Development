package StrategyDP;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Enter the amount: ");
            if (!sc.hasNextDouble()) {
                System.out.println("Invalid amount.");
                sc.close();
                return;
            }
            
            double amount = sc.nextDouble();
            sc.nextLine();
            
            System.out.println("Select the payment method:");
            System.out.println("1. Credit Card");
            System.out.println("2. Debit Card");
            System.out.println("3. UPI");
            System.out.print("Your choice: ");
            
            int choice = sc.nextInt();
            sc.nextLine();
            
            PaymentStrategy strategy;
            
            switch (choice) {
                case 1:
                    CCPayment cc = new CCPayment();
                    System.out.print("Enter Card Number: ");
                    cc.setCardNumber(sc.nextLine());
                    System.out.print("Enter CVV: ");
                    cc.setCvv(sc.nextLine());
                    System.out.print("Enter Expiry Date: ");
                    cc.setExpiryDate(sc.nextLine());
                    strategy = cc;
                    break;
                case 2:
                    DebitCardPayment dc = new DebitCardPayment();
                    System.out.print("Enter Card Number: ");
                    dc.setCardNumber(sc.nextLine());
                    System.out.print("Enter CVV: ");
                    dc.setCvv(sc.nextLine());
                    System.out.print("Enter Expiry Date: ");
                    dc.setExpiryDate(sc.nextLine());
                    strategy = dc;
                    break;
                case 3:
                    UPIPayment upi = new UPIPayment();
                    System.out.print("Enter UPI ID: ");
                    upi.setUpiId(sc.nextLine());
                    strategy = upi;
                    break;
                default:
                    System.out.println("Invalid Payment Method");
                    sc.close();
                    return;
            }
            
            PaymentProcessor processor = new PaymentProcessor(strategy);
            processor.processPayment(amount);
        }
    }
}
