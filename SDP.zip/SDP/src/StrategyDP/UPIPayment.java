package StrategyDP;

public class UPIPayment implements PaymentStrategy {
    private String upiId;

    @Override
    public void pay(double amount) {
        System.out.println("Paid Rs." + amount + " using UPI ID: " + upiId);
    }

    public void setUpiId(String upiId) {
        this.upiId = upiId;
    }

    public String getUpiId() {
        return upiId;
    }
}
