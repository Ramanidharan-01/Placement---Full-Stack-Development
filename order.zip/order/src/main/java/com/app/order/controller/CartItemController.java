package com.app.order.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.order.dto.CartItemRequest;
import com.app.order.model.CartItem;
import com.app.order.service.CartService;

import lombok.RequiredArgsConstructor; 

@RestController
@RequestMapping("/api/cart")
@RequiredArgsConstructor
public class CartItemController {
    private final CartService cartItemService;

    @PostMapping
    public ResponseEntity<String> addToCart(@RequestHeader("X-Student-ID") Long studentId , @RequestBody CartItemRequest cartItemRequest) {
        if (!cartItemService.addToCart(studentId, cartItemRequest)) {
            return ResponseEntity.badRequest().body("Product is out of Stock or User Not Found");
        }
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping("/items/{productId}")
    public ResponseEntity<Void> removeFromCartItem(@RequestHeader("X-Student-ID") Long studentId, @PathVariable Long productId) {
        cartItemService.deleteItemFromCart(studentId, productId);
        return ResponseEntity.noContent().build();
    }
    @GetMapping
    public ResponseEntity<List<CartItem>> getCartItems(@RequestHeader("X-Student-ID") Long studentId) {
        return ResponseEntity.ok(cartItemService.getCartItems(studentId));
    }
}