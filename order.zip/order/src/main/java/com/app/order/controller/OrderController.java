package com.app.order.controller;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.order.dto.OrderResponse;
import com.app.order.service.OrderService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor 
@RequestMapping("/api/orders")
public class OrderController {
    private final OrderService orderService;
    @PostMapping
    public ResponseEntity<OrderResponse> createOrder(@RequestHeader("X-Student-ID") Long studentId ){
        return orderService.createOrder(studentId).map(orderResponse->new ResponseEntity<>(orderResponse, HttpStatus.CREATED))
        .orElseGet(() -> ResponseEntity.badRequest().build());
    }
    
}