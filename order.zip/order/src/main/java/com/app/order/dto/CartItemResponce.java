package com.app.order.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;   
import lombok.Data;

@Data
@AllArgsConstructor
public class CartItemResponce {
    private Long id;
    private Long productId;
    private Integer quantity;
    private BigDecimal unitPrice;
    private BigDecimal subtotal;
}
 