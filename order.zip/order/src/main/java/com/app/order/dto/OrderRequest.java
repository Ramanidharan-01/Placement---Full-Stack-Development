package com.app.order.dto;

import java.math.BigDecimal;
import java.util.List;

import com.app.order.model.OrderStatus;

public class OrderRequest {
    private Long id;
    private BigDecimal totalAmount;
    private OrderStatus status;
    private List<OrderItemDTO> items;
}