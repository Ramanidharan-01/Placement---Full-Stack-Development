package com.app.order.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.order.model.CartItem;

@Repository
public interface CartItemRepository extends JpaRepository< CartItem, Long> {

    CartItem findByStudentIdAndProductId(Long studentId, Long productId);

    void deleteByStudentIdAndProductId(Long studentId, Long productId);

    List<CartItem> findByStudentId(Long studentId);

    void deleteByStudentId(Long studentId);
} 