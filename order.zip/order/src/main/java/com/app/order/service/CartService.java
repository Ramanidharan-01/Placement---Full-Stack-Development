package com.app.order.service;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.order.dto.CartItemRequest;
import com.app.order.model.CartItem;
import com.app.order.repository.CartItemRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CartService {

    private final CartItemRepository cartItemRepository;

    public Boolean addToCart(Long studentId, CartItemRequest cartItemRequest) {
        CartItem existingCartItem = cartItemRepository.findByStudentIdAndProductId(studentId, cartItemRequest.getProductId());
         if(existingCartItem != null) {
             existingCartItem.setQuantity(existingCartItem.getQuantity() + cartItemRequest.getQuantity());
             existingCartItem.setPrice(cartItemRequest.getPrice());
             cartItemRepository.save(existingCartItem);
         } else {
             CartItem cartItem = new CartItem();
             cartItem.setStudentId(studentId);
             cartItem.setProductId( cartItemRequest.getProductId());
             cartItem.setQuantity(cartItemRequest.getQuantity());
             cartItem.setPrice(cartItemRequest.getPrice());
             cartItemRepository.save(cartItem);
         }
         return true;
     }

     @Transactional
     public boolean deleteItemFromCart(Long studentId, Long productId) {
        CartItem cartItem= cartItemRepository.findByStudentIdAndProductId(studentId, productId);
        if(cartItem!= null) {
            cartItemRepository.delete(cartItem);
        return true;       
        }
        return false;
     }
    

     public List<CartItem> getCartItems(Long studentId) {
         return cartItemRepository.findByStudentId(studentId);
     }

     @Transactional
     public void clearCart(Long studentId) {
         cartItemRepository.deleteByStudentId(studentId);
     }

    }
