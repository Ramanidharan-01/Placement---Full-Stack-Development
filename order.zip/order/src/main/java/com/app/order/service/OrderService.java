package com.app.order.service;


import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.app.order.dto.OrderItemDTO;
import com.app.order.dto.OrderResponse;
import com.app.order.model.CartItem;
import com.app.order.model.Order;
import com.app.order.model.OrderItem;
import com.app.order.model.OrderStatus;
import com.app.order.repository.OrderRepository;

import lombok.RequiredArgsConstructor;
@Service
@RequiredArgsConstructor
public class OrderService {
    private final CartService cartItemService;
    private final OrderRepository orderRepository;

    public Optional<OrderResponse> createOrder(Long studentId){
        List<CartItem> cartItems=cartItemService.getCartItems(studentId);
        if(cartItems.isEmpty()){
            return Optional.empty();
        }
        BigDecimal totalPrice=cartItems.stream().map(CartItem::getPrice).reduce(BigDecimal.ZERO,BigDecimal::add);
        Order order=new Order();
        order.setStudentId(studentId);
        order.setStatus(OrderStatus.CONFIRMED);
        order.setTotalAmount(totalPrice);
        List<OrderItem> orderItems = cartItems.stream()
        .map(item -> new OrderItem(
                null,
                item.getProductId(),
                item.getQuantity(),
                item.getPrice(),
                order
        )).toList();
        order.setItems(orderItems);
        Order savedOrder=orderRepository.save(order);
        cartItemService.clearCart(studentId);
        return Optional.of(mapToOrderResponse(savedOrder));
    }
    private OrderResponse mapToOrderResponse(Order savedOrder){
            return new OrderResponse(
            savedOrder.getId(),
            savedOrder.getTotalAmount(),
            savedOrder.getStatus(),
            savedOrder.getItems().stream().map(orderItem->new OrderItemDTO(
                orderItem.getId(),
                orderItem.getProductId(),
                orderItem.getQuantity(),
                orderItem.getPrice(),
                orderItem.getPrice().multiply(new BigDecimal(orderItem.getQuantity()))
            )).toList()
        );
    }
}