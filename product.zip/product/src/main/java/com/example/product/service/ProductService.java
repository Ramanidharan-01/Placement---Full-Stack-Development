package com.example.product.service;

import java.util.List;

import org.jspecify.annotations.Nullable;
import org.springframework.stereotype.Service;

import com.example.product.dto.ProductRequest;
import com.example.product.dto.ProductResponse;
import com.example.product.model.Product;
import com.example.product.repository.ProductRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    public ProductResponse addProduct(ProductRequest p) {
        Product product = new Product();
        updateProductFromRequest(product, p);
        Product savedProduct = productRepository.save(product);
        return convertToResponse(savedProduct);
    }

    public List<ProductResponse> getAllProduct() {
        return productRepository.findAll().stream()
                .map(this::convertToResponse)
                .toList();
    }

    public @Nullable ProductResponse getProduct(Long id) {
        return productRepository.findById(id)
                .map(this::convertToResponse)
                .orElse(null);
    }

    public @Nullable ProductResponse updateProduct(Long id, ProductRequest p) {
        return productRepository.findById(id)
                .map(existingProduct -> {
                    updateProductFromRequest(existingProduct, p);
                    Product updatedProduct = productRepository.save(existingProduct);
                     return convertToResponse(updatedProduct);
                })
                .orElse(null);
    }

    public boolean deleteProduct(Long id) {
        if (productRepository.existsById(id)) {
            productRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public ProductResponse convertToResponse(Product product) {
        ProductResponse response = new ProductResponse();
        response.setId(product.getId());
        response.setName(product.getName());
        response.setDescription(product.getDescription());
        response.setPrice(product.getPrice());
        response.setCategory(product.getCategory());
        response.setStockQuantity(product.getStockQuantity());
        response.setImageUrl(product.getImageUrl());
        response.setActive(product.isActive());
        return response;
    }

    private void updateProductFromRequest(Product product, ProductRequest p) {
        product.setName(p.getName());
        product.setDescription(p.getDescription());
        product.setPrice(p.getPrice());
        product.setCategory(p.getCategory());
        product.setStockQuantity(p.getStockQuantity());
        product.setImageUrl(p.getImageUrl());
        product.setActive(p.isActive());
    }

    public List<ProductResponse> searchProduct(String keyword){
        return productRepository.searchProducts(keyword)
                .stream().map(this::convertToResponse)
                .toList();
    }
}
