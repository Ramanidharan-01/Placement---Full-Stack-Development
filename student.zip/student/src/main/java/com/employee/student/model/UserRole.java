package com.employee.student.model;

public enum UserRole {
    STUDENT,
    TEACHER,
    ADMIN
}
 