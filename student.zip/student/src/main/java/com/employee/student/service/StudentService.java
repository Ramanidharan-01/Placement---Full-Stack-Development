package com.employee.student.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.employee.student.dto.AddressDTO;
import com.employee.student.dto.StudentRequest;
import com.employee.student.dto.StudentResponse;
import com.employee.student.model.Student;
import com.employee.student.repository.StudentRepository;

import lombok.RequiredArgsConstructor;
 
@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;

    public List<StudentResponse> getAllStudent() {
        return studentRepository.findAll().stream()
                .map(this::convertToResponse)
                .collect(Collectors.toList());
    }

    public StudentResponse addStudent(Student s) {
        studentRepository.save(s);
        return convertToResponse(s);
    }

    public StudentResponse getStudent(Long id) {
        return studentRepository.findById(id).map(this::convertToResponse).orElse(null);
    }

    public StudentResponse updateStudent(Long id, StudentRequest s) {
        Student student = studentRepository.findById(id).orElse(null);
        if (student == null) {
            return null;
        }
        student.setFirstName(s.getFirstName());
        student.setLastName(s.getLastName());
        student.setEmail(s.getEmail());
        student.setPhone(s.getPhone());
        if (s.getAddress() != null) {
            student.setAddress(s.getAddress());
        }
        studentRepository.save(student);
        return convertToResponse(student);
    }

    public String deleteStudent(Long id) {
        if (studentRepository.existsById(id)) {
            studentRepository.deleteById(id);
            return "Student Deleted Successfully";
        }

        return "Student Not Found";
    }

    public StudentResponse convertToResponse(Student student) {
        StudentResponse response = new StudentResponse();
        response.setId(student.getId());
        response.setFirstName(student.getFirstName());
        response.setLastName(student.getLastName());
        response.setEmail(student.getEmail());
        response.setPhone(student.getPhone());
        if (student.getAddress() != null) {
            AddressDTO addressDTO = new AddressDTO();
            addressDTO.setStreetid(student.getAddress().getStreetid());
            addressDTO.setStreet(student.getAddress().getStreet());
            addressDTO.setCity(student.getAddress().getCity());
            addressDTO.setState(student.getAddress().getState());
            addressDTO.setCountry(student.getAddress().getCountry());
            addressDTO.setZipcode(student.getAddress().getZipcode());
            response.setAddress(addressDTO);
        }
        return response;
    }
}